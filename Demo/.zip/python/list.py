{
    "ubuntuGuest": {
        "hosts": [
            "10.10.10.1"
        ]
      }
}

